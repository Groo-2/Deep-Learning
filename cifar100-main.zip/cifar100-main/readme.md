# 📘 CIFAR-100 전이학습 기반 이미지 분류 프로젝트

## 📌 프로젝트 개요

- **목표**: CIFAR-100 데이터셋을 기반으로 전이학습(Transfer Learning)을 활용한 이미지 분류 모델을 구현하고, 정확도와 효율성을 모두 고려한 성능 최적화를 진행함.
- **활용 모델**: PyTorch 기반 사전학습(pretrained) 모델  
  - ✅ EfficientNet-B0  
  - ✅ EfficientNet-B3  
  - ✅ DenseNet121

---

## 🛠 현재 진행 상황

- ✅ **WSL (Ubuntu 22.04)** 환경에서 개발 진행 중
- ✅ **VS Code 연동 완료**
- ✅ 모델 로딩 및 classifier 수정 함수 구성 (`get_model()` in `models.py`)
- ✅ CIFAR-100 DataLoader 및 transform 구성 (`dataset.py`)
- ✅ 학습 전체 파이프라인 구축 (`train.py`)
  - `--model`, `--batch_size` 인자 사용 가능
  - 배치사이즈에 따라 학습률 자동 조정
  - epoch 1~39: 저장 안 함 / epoch 40~100: `.pth` 저장
  - `training_log.txt`로 전체 결과 기록
- ✅ 자동 반복 학습 스크립트 구현 (`batch_runner.py`)
  - 모델 3종 × 배치사이즈 3종 = 총 9조합 실행
- ✅ 테스트셋(CImages) 준비 완료 (`./Dataset/CImages`)
- ✅ 제출 양식 결과 `.txt` 자동 생성 스크립트 구현 완료 (`result_generator.py`)

---

## 📁 디렉토리 구조

```
cifar100_transfer_learning/
├── train.py               # 학습 전체 파이프라인
├── batch_runner.py        # 모델/배치 조합 자동 학습 스크립트
├── models.py              # 모델 불러오기 및 classifier 교체
├── dataset.py             # CIFAR-100 DataLoader + transform
├── result_generator.py    # 제출용 result_*.txt 생성기
├── weights/               # 학습된 모델 저장 폴더 (.pth + 로그)
├── results/               # 테스트셋 추론 결과 저장 위치
├── Dataset/
│   └── CImages/           # 테스트용 이미지 (0001.jpg ~ 3000.jpg)
└── README.md              # 프로젝트 설명 및 실행 방법
```

---

## 🚀 실행 방법 요약

### 1. 단일 모델 학습 (예시)

```bash
python train.py --model efficientnet_b0 --batch_size 128
```

- 자동으로 `weights/efficientnet_b0_0529_0310/` 폴더 생성
- `epoch040.pth` ~ `epoch100.pth` 저장
- `training_log.txt`에 학습 결과 전체 기록됨

---

### 2. 여러 모델/배치 자동 반복 학습

```bash
python batch_runner.py
```

- 모델 3종 × 배치사이즈 3종 = 총 9회 학습 자동 실행
- 각각 고유의 weights 폴더에 저장됨

---

### 3. CImages 테스트셋 추론 결과 생성

```bash
python result_generator.py --model efficientnet_b0 --weight weights/efficientnet_b0_0529_0310/epoch089.pth
```

- 결과는 `results/result_가반1조_0529_0310.txt`로 저장됨
- 추론 포맷: `number,label` (0001, 23)

---

## ✅ 제출 시 포함 항목 (경진대회 규정 준수)

- 모델 학습 코드: `classifier_가반1조_0602_1410.py` → `train.py`에서 복사
- 학습된 가중치: `weight_가반1조_0602_1410.pth`
- 테스트셋 추론 결과: `result_가반1조_0602_1410.txt`
- `training_log.txt` 내 CIFAR-100 train/test accuracy 기록 포함

---

## ⚠️ 주의사항

- **CIFAR-100의 testset**은 학습에 절대 사용 불가
- `CImages.zip`의 3000장은 정답 라벨이 없음 (추론 결과만 제출)
- 학습 정확도(`Train Acc`)와 검증 정확도(`Val Acc`)는 `training_log.txt`에서 확인 가능
