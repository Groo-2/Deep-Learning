import torch.nn as nn
from torchvision.models import (
    efficientnet_b0, efficientnet_b3, densenet121,
    EfficientNet_B0_Weights, EfficientNet_B3_Weights, DenseNet121_Weights
)

def get_model(model_name: str):
    if model_name == 'efficientnet_b0':
        weights = EfficientNet_B0_Weights.DEFAULT
        model = efficientnet_b0(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 100)

    elif model_name == 'efficientnet_b3':
        weights = EfficientNet_B3_Weights.DEFAULT
        model = efficientnet_b3(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 100)

    elif model_name == 'densenet121':
        weights = DenseNet121_Weights.DEFAULT
        model = densenet121(weights=weights)
        model.classifier = nn.Linear(model.classifier.in_features, 100)

    else:
        raise ValueError(f"지원하지 않는 모델 이름입니다: {model_name}")

    return model
