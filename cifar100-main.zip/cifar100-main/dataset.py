from torchvision import datasets, transforms
from torchvision.transforms import RandAugment
from torch.utils.data import DataLoader

def get_cifar100_dataloaders(batch_size=128, num_workers=2, input_size=224):
    """
    CIFAR-100 train/test DataLoader 생성 함수 (고급 Augmentation 포함)

    Args:
        batch_size (int): 배치 크기
        num_workers (int): DataLoader 병렬 처리 수
        input_size (int): 모델 입력 해상도 (e.g. 224)
    Returns:
        train_loader, test_loader
    """

    # CIFAR-100 공식 Mean, Std
    mean = (0.5071, 0.4867, 0.4408)
    std  = (0.2675, 0.2565, 0.2761)

    # Train용 transform
    train_transform = transforms.Compose([
        # 1) 업샘플링 → pretrained 모델이 기대하는 크기로
        transforms.Resize(input_size),
        # 2) 랜덤 크롭 + 좌우 뒤집기
        transforms.RandomCrop(input_size, padding=4),
        transforms.RandomHorizontalFlip(),
        # 3) RandAugment: Color, Rotation, Sharpness 등 랜덤 강화
        RandAugment(num_ops=2, magnitude=9),
        # 4) Tensor 변환 + 정규화
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])

    # Test용 transform (학습 때와 동일하게 Resize + Normalize)
    test_transform = transforms.Compose([
        transforms.Resize(input_size),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])

    # CIFAR-100 Dataset (download=True는 한 번만 다운)
    train_dataset = datasets.CIFAR100(
        root='./data', train=True, download=True, transform=train_transform
    )
    test_dataset = datasets.CIFAR100(
        root='./data', train=False, download=True, transform=test_transform
    )

    # DataLoader 생성
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )

    return train_loader, test_loader
