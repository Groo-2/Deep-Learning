import datetime
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import os
import argparse
from tqdm import tqdm
from torchinfo import summary
from models import get_model
from dataset import get_cifar100_dataloaders

# ----------------------------------------
# argparse 설정
# ----------------------------------------
parser = argparse.ArgumentParser()
parser.add_argument("--model", type=str, default="efficientnet_b0", help="Model name")
parser.add_argument("--batch_size", type=int, default=128, help="Batch size")
parser.add_argument("--mixup_alpha", type=float, default=0.2, help="Mixup alpha (0 = off)")
parser.add_argument("--freeze_epochs", type=int, default=5, help="Epochs to freeze backbone")
args = parser.parse_args()

# ----------------------------------------
# 하이퍼파라미터
# ----------------------------------------
max_epochs   = 100
min_epochs   = 20   # 최소 보장 epoch
patience     = 10   # early stopping patience
no_improve   = 0
best_acc     = 0.0
base_lr      = 0.001
batch_size   = args.batch_size
lr           = base_lr * (batch_size / 128)

# Dropout 스케줄 설정
initial_dropout   = 0.5      # 에포크1에서의 p
dropout_epochs    = 20       # 몇 epoch 동안 감소시킬지
final_dropout     = 0.0      # 에포크 >= dropout_epochs 에서 고정될 p

# ----------------------------------------
# 저장 폴더 & 로그
# ----------------------------------------
# 고유 폴더명: 모델 + 배치사이즈 + mixup + freeze 조합
# 고유 폴더명: 모델 + 배치사이즈 + mixup + freeze + timestamp 조합
timestamp   = datetime.now().strftime("%m%d_%H%M%S")
folder_name = (
    f"{args.model}_"
    f"b{args.batch_size}_"
    f"mix{args.mixup_alpha}_"
    f"f{args.freeze_epochs}_"
    f"{timestamp}"
)
save_dir = os.path.join("weights", folder_name)
os.makedirs(save_dir, exist_ok=True)

log_path = os.path.join(save_dir, "training_log.txt")
log_file = open(log_path, "w")
log_file.write("epoch,train_acc,val_acc,loss,is_best,dropout\n")
# ----------------------------------------
# 장치 설정
# ----------------------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ----------------------------------------
# 모델 & 데이터
# ----------------------------------------
model = get_model(args.model).to(device)

## classifier 맨 앞에 Dropout 레이어 삽입 (초기 p=initial_dropout)
if isinstance(model.classifier, nn.Sequential):
    # get existing layers
    layers = list(model.classifier)
    # new Sequential: [Dropout, 기존 layers...]
    model.classifier = nn.Sequential(
        nn.Dropout(p=initial_dropout),
        *layers
    )
else:
    # single Linear classifier (e.g. DenseNet)
    model.classifier = nn.Sequential(
        nn.Dropout(p=initial_dropout),
        model.classifier
    )
# 편하게 나중에 p를 수정하기 위한 참조
dropout_layer = model.classifier[0]
model.eval()  # summary 전에 꼭 eval()

# 기존: summary(model, (3, 224, 224), device=str(device))
summary(model, input_size=(batch_size, 3, 224, 224), device=device.type)

train_loader, val_loader = get_cifar100_dataloaders(
    batch_size=batch_size, num_workers=4, input_size=224
)

# ----------------------------------------
# 손실함수 & optimizer/scheduler 생성 함수
# → model.parameters()를 넘겨야 합니다
# ----------------------------------------
criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
def make_optim_scheduler(params, lr):
    optim_ = optim.Adam(params, lr=lr)
    sched_ = optim.lr_scheduler.CosineAnnealingLR(optim_, T_max=max_epochs)
    return optim_, sched_

optimizer, scheduler = make_optim_scheduler(model.parameters(), lr)

# ----------------------------------------
# Mixup 유틸
# ----------------------------------------
def mixup_data(x, y, alpha):
    if alpha <= 0:
        return x, y, y, 1.0
    lam = np.random.beta(alpha, alpha)
    idx = torch.randperm(x.size(0)).to(device)
    mixed_x = lam*x + (1-lam)*x[idx]
    return mixed_x, y, y[idx], lam

# ----------------------------------------
# 평가 함수
# ----------------------------------------
def evaluate(model, loader):
    model.eval()
    correct = 0
    total   = 0
    with torch.no_grad():
        for imgs, lbls in loader:
            imgs, lbls = imgs.to(device), lbls.to(device)
            out = model(imgs)
            pred = out.argmax(dim=1)
            correct += pred.eq(lbls).sum().item()
            total   += lbls.size(0)
    return 100. * correct / total

# ----------------------------------------
# 학습 루프
# ----------------------------------------
for epoch in range(1, max_epochs+1):
    # --- Dropout Scheduling ---
    if epoch <= dropout_epochs:
        # 선형 감소: epoch=1 → p=initial_dropout, epoch=dropout_epochs → p=final_dropout
        new_p = initial_dropout * (1 - (epoch-1)/(dropout_epochs-1))
    else:
        new_p = final_dropout
    dropout_layer.p = new_p
    # -----------------------------
    
    # Freeze→Unfreeze
    if epoch == 1:
        for n,p in model.named_parameters():
            p.requires_grad = "classifier" in n
        optimizer, scheduler = make_optim_scheduler(
            filter(lambda p: p.requires_grad, model.parameters()), lr
        )
    if epoch == args.freeze_epochs + 1:
        for p in model.parameters():
            p.requires_grad = True
        # model 전체 parameter를 넘겨야 합니다
        optimizer, scheduler = make_optim_scheduler(model.parameters(), lr*0.1)

    model.train()
    running_loss = 0.0
    correct = 0; total = 0

    for imgs, lbls in tqdm(train_loader, desc=f"Epoch {epoch:03d}"):
        imgs, lbls = imgs.to(device), lbls.to(device)
        imgs, ya, yb, lam = mixup_data(imgs, lbls, args.mixup_alpha)

        optimizer.zero_grad()
        outputs = model(imgs)
        loss = lam*criterion(outputs, ya) + (1-lam)*criterion(outputs, yb)
        loss.backward()
        optimizer.step()

        preds = outputs.argmax(dim=1)
        correct += lam*preds.eq(ya).sum().item() + (1-lam)*preds.eq(yb).sum().item()
        total   += lbls.size(0)
        running_loss += loss.item()

    train_acc = 100. * correct / total
    val_acc   = evaluate(model, val_loader)

    # 로그 & 체크포인트
    is_best = 0
    if val_acc > best_acc:
        best_acc   = val_acc
        no_improve = 0
        is_best    = 1
        print(f"✅ New BEST at epoch {epoch:03d} → Val Acc: {val_acc:.2f}%")
        log_file.write(f"\nNew BEST at epoch {epoch},{train_acc:.2f},{val_acc:.2f},{new_p:.3f}\n")
     
    else:
        if epoch > min_epochs:
            no_improve += 1

    print(f"{epoch},{train_acc:.2f},{val_acc:.2f},{running_loss:.4f},{is_best}\n")
    log_file.write(f"{epoch},{train_acc:.2f},{val_acc:.2f},{running_loss:.4f},{is_best},{new_p:.3f}\n")     
    log_file.flush()

    # 매 epoch 저장
    torch.save({
        'epoch': epoch,
        'model_state_dict':    model.state_dict(),
        'optimizer_state_dict':optimizer.state_dict(),
        'scheduler_state_dict':scheduler.state_dict(),
        'val_acc':             val_acc
    }, os.path.join(save_dir, f"epoch{epoch:03d}.pth"))

    # Scheduler는 에포크 끝에서 호출 (optimizer.step 다음)
    scheduler.step()

    # Early stopping
    if epoch >= min_epochs and no_improve >= patience:
        print(f"🌟 Early stopping at epoch {epoch} (no imp {patience})")
        break

log_file.close()
print(f"\nDone. Checkpoints in {save_dir}")