import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import os
import glob
from models import get_model
import argparse
import datetime

def load_image(img_path, transform):
    image = Image.open(img_path).convert("RGB")
    return transform(image)

def generate_result(model_name, weight_path, save_dir="results"):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(model_name).to(device)
    model.load_state_dict(torch.load(weight_path, map_location=device))
    model.eval()

    # 이미지 전처리 (test용)
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761))
    ])

    image_folder = "./Dataset/CImages"
    image_paths = sorted(glob.glob(os.path.join(image_folder, "*.jpg")))

    results = []

    with torch.no_grad():
        for path in image_paths:
            filename = os.path.basename(path).split('.')[0]  # 0001
            image = load_image(path, transform).unsqueeze(0).to(device)
            output = model(image)
            _, predicted = output.max(1)
            label = predicted.item()
            results.append(f"{filename},{label:02d}")

    # 결과 저장
    now = datetime.datetime.now().strftime("%m%d_%H%M")
    save_name = f"result_가반1조_{now}.txt"
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, save_name)

    with open(save_path, "w") as f:
        f.write("number,label\n")
        for line in results:
            f.write(line + "\n")

    print(f"✅ 추론 결과가 {save_path}에 저장되었습니다.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, required=True, help="모델 이름 (efficientnet_b0, efficientnet_b3, densenet121)")
    parser.add_argument('--weight', type=str, required=True, help=".pth weight 파일 경로")
    args = parser.parse_args()

    generate_result(args.model, args.weight)
