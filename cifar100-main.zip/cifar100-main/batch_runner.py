import subprocess

models = ["efficientnet_b0", "efficientnet_b3", "densenet121"]
batch_sizes = [64, 128, 256]
mixup_alphas = [0.0, 0.2]
freeze_epochs_list = [0, 5]

# 4번 반복
for run_idx in range(4):
    print(f"\n🔄 전체 조합 실행 라운드 {run_idx+1}/4 시작\n")
    for model in models:
        for batch in batch_sizes:
            for mixup_alpha in mixup_alphas:
                for freeze_epochs in freeze_epochs_list:
                    print(f"🚀 실행 중: {model}, batch={batch}, mixup={mixup_alpha}, freeze={freeze_epochs}")
                    cmd = [
                        "python3", "train.py",
                        "--model", model,
                        "--batch_size", str(batch),
                        "--mixup_alpha", str(mixup_alpha),
                        "--freeze_epochs", str(freeze_epochs)
                    ]
                    subprocess.run(cmd)
    print(f"\n✅ 라운드 {run_idx+1}/4 완료\n")